﻿{
  Задание 8. Тайный код пиратов
}
begin
  var s := ReadString;
  s.Matches('[pP]\d{3}').Count.Print;
end.

