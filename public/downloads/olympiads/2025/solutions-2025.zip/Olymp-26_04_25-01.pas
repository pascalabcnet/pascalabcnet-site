﻿{
  Задание 1. Игра
}
begin
  var (a,b) := ReadInteger2;
  if Abs(a-b)<=3 then
    Print('Alice')
  else Print('Bob');
end.

