﻿{
  Задание 4. Лингвист
}
begin
  var s := ReadString;
  var res := s.ToWords.EachCount.OrderByDescending(kv -> kv.Value)
    .ThenByDescending(kv -> kv.Key.Length).ThenBy(kv -> kv.Key);
  foreach var x in res do
    Println(x.Key,x.Value);  
end.

