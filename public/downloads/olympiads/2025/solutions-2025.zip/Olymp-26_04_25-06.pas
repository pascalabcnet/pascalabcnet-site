﻿{
  Задание 6. Шифр Цезаря
}

function decode(c: char; k: integer): char;
begin
  if c in 'A'..'Z' then
  begin  
    Dec(c,k);
    if c < 'A' then
      Inc(c,26);
  end;
  Result := c;
end;

begin
  var k := ReadlnInteger;
  var s := ReadString;
  s.Select(c -> decode(c,k)).JoinToString.Print;
end.

