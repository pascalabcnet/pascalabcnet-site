﻿{
  Задание 2. Подарок для Алисы
}
begin
  var (N,M) := ReadInteger2;
  var a := ReadArrInteger(N);
  var max := -MaxInt;
  for var i:=0 to a.Length-1 do
  for var j:=i+1 to a.Length-1 do
  begin
    if (a[i] + a[j] <= M) and (a[i] + a[j] > max) then
      max := a[i] + a[j];
  end;
  if max = -MaxInt then
    max := 0;
  Print(max);
end.

