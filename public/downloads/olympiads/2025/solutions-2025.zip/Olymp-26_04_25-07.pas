﻿{
  Задание 7. Бинарные даты
}
uses School;

begin
  var (x,y) := ReadInteger2;
  var count := 0;
  for var i:=x to y do
    if i.Digits.All(d -> d in [0,1]) then
      count += 1;
  Print(count);
end.
