﻿{
  Задание 5. Популярные элементы
}
begin
  var k := ReadInteger;
  var N := ReadlnInteger;
  var sets := new List<set of integer>;
  loop k do
    sets.Add(ReadString.ToIntegers.ToSet);
  
  var dict := new Dictionary<integer, List<integer>>;
  
  foreach var i in 0..k-1 do
    foreach var x in sets[i] do
    begin  
      if x not in dict then
        dict[x] := [];
      dict[x].Add(i+1)
    end;
  
  foreach var kv in dict.Where(p -> p.Value.Count >= n).OrderBy(p -> p.Key) do
  begin
    Print(kv.Key,':');
    kv.Value.Order.Println;
  end;
end.

