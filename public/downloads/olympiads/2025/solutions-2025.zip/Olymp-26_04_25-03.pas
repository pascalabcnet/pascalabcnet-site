﻿{
  Задание 3. Орёл или решка
}
begin
  var N := ReadInteger;
  var res := 1 - 0.5 ** N;
  Print(Round(res * 1000)/1000);
  
end.

