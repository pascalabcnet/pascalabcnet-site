﻿{
  Задание B2. Прибыль
}
begin
  var n := ReadInteger;
  var a := ReadArrInteger(n);
  var maxProfit := 0;
  for var i := 0 to n - 1 do
    for var j := i + 1 to n - 1 do
      maxProfit := max(maxProfit, a[j] - a[i]);

  Print(maxProfit);
end.

