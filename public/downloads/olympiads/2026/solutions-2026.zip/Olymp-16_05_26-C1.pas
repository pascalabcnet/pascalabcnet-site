{
  Задание C1. Анаграммы
}
begin
  var words := ReadString.ToWords;
  Print(words.GroupBy(w -> w.Order.JoinToString).Max(g -> g.Count));
end.

