﻿{
  Задание A1. Качели
}
begin
  var (a,b,c,d) := ReadInteger4;
  var res := Min(Abs(a+b-c-d), Abs(a+c-b-d));
  res := Min(res, Abs(a+d-b-c));
  Print(res);
end.

