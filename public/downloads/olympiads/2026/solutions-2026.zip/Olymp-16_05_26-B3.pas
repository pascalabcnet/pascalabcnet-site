{
  Задание B3. Самое частое слово
}
begin
  var s := ReadString;
  var d := s.ToWords.EachCount;
  var bestWord := '';
  var bestCount := -1;
  foreach var kv in d do
    if (kv.Value > bestCount) or ((kv.Value = bestCount) and (kv.Key > bestWord)) then
    begin
      bestWord := kv.Key;
      bestCount := kv.Value;
    end;
  Print(bestWord);
end.

