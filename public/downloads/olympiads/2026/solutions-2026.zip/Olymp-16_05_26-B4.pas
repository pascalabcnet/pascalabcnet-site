{
  Задание B4. Без повторов
}
begin
  var n := ReadInteger;
  var a := ReadArrInteger(n);
  var last := new Dictionary<integer, integer>;
  var left := 0;
  var res := 0;
  for var r:=0 to n-1 do
  begin
    if (a[r] in last) and (last[a[r]] >= left) then
      left := last[a[r]] + 1;
    last[a[r]] := r;
    res := Max(res, r - left + 1);
  end;
  Print(res);
end.

