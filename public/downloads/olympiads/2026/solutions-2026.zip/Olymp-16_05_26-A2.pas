{
  Задание A2. Минимальная и максимальная цифры
}
begin
  var n := ReadInteger;
  var mn := 9;
  var mx := 0;
  repeat
    var d := n mod 10;
    mn := Min(mn,d);
    mx := Max(mx,d);
    n := n div 10;
  until n = 0;
  Print(mn,mx);
end.
