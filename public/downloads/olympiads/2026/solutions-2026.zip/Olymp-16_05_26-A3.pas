﻿{
  Задание A3. Разрывы
}
begin
  var s := ReadString;
  var count := 0;
  for var i:=2 to s.Length do
    if s[i] <> s[i-1] then
      count += 1;
  Print(count);
end.
