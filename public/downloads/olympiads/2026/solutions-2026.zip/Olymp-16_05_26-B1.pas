﻿{
  Задание B1. Зеркальные числа
}
begin
  var n := ReadInteger;
  var a := ReadArrInteger(n);
  Print(a.Count(x -> (x > 0) and (-x in a)));
end.

